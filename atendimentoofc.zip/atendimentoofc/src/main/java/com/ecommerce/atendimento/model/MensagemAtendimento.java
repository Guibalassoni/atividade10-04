package com.ecommerce.atendimento.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
public class MensagemAtendimento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String conteudo;
    private LocalDateTime dataEnvio;
    private boolean enviadoPeloCliente;

    @ManyToOne
    @JoinColumn(name = "atendimento_id")
    private Atendimento atendimento;

    public MensagemAtendimento() {
    }

    public MensagemAtendimento(String conteudo, boolean enviadoPeloCliente, Atendimento atendimento) {
        this.conteudo = conteudo;
        this.enviadoPeloCliente = enviadoPeloCliente;
        this.atendimento = atendimento;
        this.dataEnvio = LocalDateTime.now();
    }

    // Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public LocalDateTime getDataEnvio() {
        return dataEnvio;
    }

    public void setDataEnvio(LocalDateTime dataEnvio) {
        this.dataEnvio = dataEnvio;
    }

    public boolean isEnviadoPeloCliente() {
        return enviadoPeloCliente;
    }

    public void setEnviadoPeloCliente(boolean enviadoPeloCliente) {
        this.enviadoPeloCliente = enviadoPeloCliente;
    }

    public Atendimento getAtendimento() {
        return atendimento;
    }

    public void setAtendimento(Atendimento atendimento) {
        this.atendimento = atendimento;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MensagemAtendimento that = (MensagemAtendimento) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(dataEnvio, that.dataEnvio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, dataEnvio);
    }

    @Override
    public String toString() {
        return "MensagemAtendimento{" +
                "id=" + id +
                ", dataEnvio=" + dataEnvio +
                ", enviadoPeloCliente=" + enviadoPeloCliente +
                '}';
    }
}