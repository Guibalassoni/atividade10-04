package com.ecommerce.atendimento.service;

import com.ecommerce.atendimento.model.Pedido;
import com.ecommerce.atendimento.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PedidoService {
    private final PedidoRepository repository;

    @Autowired
    public PedidoService(PedidoRepository repository) {
        this.repository = repository;
    }

    public List<Pedido> listarTodos() {
        return repository.findAll();
    }

    public Pedido buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido não encontrado com ID: " + id));
    }

    public Pedido salvar(Pedido pedido) {
        return repository.save(pedido);
    }

    public void deletar(Integer id) {
        repository.deleteById(id);
    }

    public List<Pedido> buscarPorCliente(Integer clienteId) {
        return repository.findByClienteId(clienteId);
    }

    public List<Pedido> buscarPorStatus(String status) {
        return repository.findByStatus(status);
    }
}