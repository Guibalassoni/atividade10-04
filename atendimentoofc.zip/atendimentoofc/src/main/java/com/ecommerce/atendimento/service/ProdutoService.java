package com.ecommerce.atendimento.service;

import com.ecommerce.atendimento.model.Produto;
import com.ecommerce.atendimento.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {
    private final ProdutoRepository repository;

    @Autowired
    public ProdutoService(ProdutoRepository repository) {
        this.repository = repository;
    }

    public List<Produto> listarTodos() {
        return repository.findAll();
    }

    public Produto buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado com ID: " + id));
    }

    public Produto cadastrar(Produto produto) {
        return repository.save(produto);
    }

    public Produto atualizar(Integer id, Produto produto) {
        Produto existente = buscarPorId(id);
        produto.setId(existente.getId());
        return repository.save(produto);
    }

    public void deletar(Integer id) {
        repository.deleteById(id);
    }

    public List<Produto> buscarPorCategoria(String categoria) {
        return repository.findByCategoria(categoria);
    }
}