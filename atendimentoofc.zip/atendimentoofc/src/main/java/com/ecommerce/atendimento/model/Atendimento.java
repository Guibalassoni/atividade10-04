package com.ecommerce.atendimento.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@Entity
public class Atendimento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String assunto;
    private String descricao;
    private LocalDateTime dataAbertura;
    private LocalDateTime dataFechamento;
    private String status;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @OneToOne
    @JoinColumn(name = "pedido_id")
    private Pedido pedido;

    @OneToMany(mappedBy = "atendimento", cascade = CascadeType.ALL)
    private List<MensagemAtendimento> mensagens;

    // Construtores
    public Atendimento() {
    }

    public Atendimento(String assunto, String descricao, Cliente cliente, Pedido pedido) {
        this.assunto = assunto;
        this.descricao = descricao;
        this.cliente = cliente;
        this.pedido = pedido;
        this.dataAbertura = LocalDateTime.now();
        this.status = "ABERTO";
    }

    // Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDateTime getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(LocalDateTime dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public LocalDateTime getDataFechamento() {
        return dataFechamento;
    }

    public void setDataFechamento(LocalDateTime dataFechamento) {
        this.dataFechamento = dataFechamento;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public List<MensagemAtendimento> getMensagens() {
        return mensagens;
    }

    public void setMensagens(List<MensagemAtendimento> mensagens) {
        this.mensagens = mensagens;
    }

    // equals e hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Atendimento that = (Atendimento) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(dataAbertura, that.dataAbertura);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, dataAbertura);
    }

    // toString
    @Override
    public String toString() {
        return "Atendimento{" +
                "id=" + id +
                ", assunto='" + assunto + '\'' +
                ", status='" + status + '\'' +
                ", dataAbertura=" + dataAbertura +
                '}';
    }
}