package com.ecommerce.atendimento.repository;

import com.ecommerce.atendimento.model.Atendimento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AtendimentoRepository extends JpaRepository<Atendimento, Integer> {
    List<Atendimento> findByClienteId(Integer clienteId);
    List<Atendimento> findByStatus(String status);
}