package com.ecommerce.atendimento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtendimentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
